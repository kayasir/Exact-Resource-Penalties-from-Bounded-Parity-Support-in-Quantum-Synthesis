"""Deterministic vector schematic of exact synthesis and a reversible phase gadget."""
from pathlib import Path
import argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
R=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=R)
args=parser.parse_args()
OUT=args.output_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Nimbus Sans','Arial','DejaVu Sans'],'mathtext.fontset':'stix','font.size':9,'pdf.fonttype':42,'ps.fonttype':3})
ink='#172F47';blue='#2462A6';orange='#C55A13';teal='#007D78';purple='#7045A1';gray='#697B8C'
f,ax=plt.subplots(figsize=(7.1,2.45))
f.subplots_adjust(0,0,1,1);ax.set(xlim=(0,100),ylim=(0,35));ax.axis('off')
def txt(x,y,t,size=9,c=ink,ha='left',bold=False):
 ax.text(x,y,t,fontsize=size,color=c,ha=ha,va='center',weight='bold' if bold else 'normal',zorder=8)
def box(x,y,w,h,fc,ec='none',lw=.85):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=.65',fc=fc,ec=ec,lw=lw,zorder=2))
def ar(x,y,u,v,c=ink):
 ax.add_patch(FancyArrowPatch((x,y),(u,v),arrowstyle='-|>',mutation_scale=8,lw=1.05,color=c,zorder=5))
txt(1,32.8,'(a)',11,bold=True);txt(6,32.8,'Representation and exact synthesis',9.4,bold=True)
txt(52,32.8,'(b)',11,bold=True);txt(57,32.8,'A parity phase from two-qubit gates',9.3,bold=True)
ax.plot([50,50],[1.4,30.7],color='#DCE3E9',lw=.8)
# The catalogue is the only change between the synthesis problems.
box(1.5,25.6,46,4.5,'#EDF2F7')
txt(24.5,27.85,r'Same target  $U_p$  and signature  $\sigma$',9.4,ink,'center')
ar(18,25.55,12.3,23.65,orange);ar(31,25.55,36.7,23.65,teal)
box(1.5,16.4,21.8,7.1,'#FFF2E9',orange);box(25.7,16.4,21.8,7.1,'#E9F5F2',teal)
txt(12.4,21.45,'Bounded support',9.1,orange,'center',True)
txt(36.6,21.45,'Unrestricted support',9.1,teal,'center',True)
txt(12.4,18.55,r'$1\leq |a|\leq k$',10.7,orange,'center')
txt(36.6,18.55,r'$a\neq 0$',10.7,teal,'center')
ar(12.4,16.25,12.4,14.7,orange);ar(36.6,16.25,36.6,14.7,teal)
txt(12.4,13.7,r'$T_k(p)$',11,orange,'center');txt(36.6,13.7,r'$T_*^{\mathrm{ph}}(p)$',11,teal,'center')
txt(24.5,10.6,r'Minimize $|z|$ with $Hz=\sigma$ in each set',8.8,ink,'center')
ar(24.5,9.45,24.5,8.55,blue)
box(1.5,4.4,46,4.1,'#EDF2F7');txt(24.5,6.45,r'Even completion restores $p$ modulo $8$',9.2,ink,'center')
txt(24.5,1.85,'Fixed input coordinates; identical unitary',8.8,gray,'center')
# CNOT 1->4, CNOT 2->4, T^c, inverse CNOTs. Wire 3 is untouched.
ys=[23.4,18.9,14.4,9.9]
box(59.3,7.5,10.5,18.1,'#EDF3FA');box(84,7.5,10.5,18.1,'#EDF3FA')
txt(64.55,27.8,'Compute',8.9,blue,'center',True);txt(76.9,27.8,'Phase',8.9,purple,'center',True);txt(89.25,27.8,'Uncompute',8.9,blue,'center',True)
for i,y in enumerate(ys):
 txt(52,y,rf'$x_{i+1}$',10);ax.plot([57.4,96],[y,y],c=gray,lw=.8,zorder=3);txt(98.4,y,rf'$x_{i+1}$',10,ha='center')
def cx(x,control):
 ax.plot([x,x],[ys[control],ys[3]],c=blue,lw=1.2,zorder=5)
 ax.add_patch(Circle((x,ys[control]),.42,fc=blue,zorder=6))
 ax.add_patch(Circle((x,ys[3]),.80,fc='white',ec=blue,lw=1.1,zorder=6))
 ax.plot([x-.53,x+.53],[ys[3],ys[3]],c=blue,lw=.9,zorder=7)
 ax.plot([x,x],[ys[3]-.53,ys[3]+.53],c=blue,lw=.9,zorder=7)
cx(61.8,0);cx(67.3,1);cx(86.5,1);cx(92,0)
box(73.9,7.65,6,4.5,purple);ax.patches[-1].set_zorder(6);txt(76.9,9.9,r'$T^c$',11,'white','center')
txt(76.9,16.6,r'$\ell=x_1\oplus x_2\oplus x_4$',9.4,ink,'center')
txt(64.55,5.55,r'$C_\ell$',10.5,blue,'center');txt(89.25,5.55,r'$C_\ell^{-1}$',10.5,blue,'center')
txt(76,1.8,r'$|x\rangle\;\longmapsto\;e^{i\pi c\ell(x)/4}|x\rangle$',10.5,ink,'center')
for ext in ['pdf','eps','svg']:f.savefig(OUT/f'Fig1.{ext}',facecolor='white')
f.savefig(OUT/'Fig1.jpg',dpi=600,pil_kwargs={'quality':97})

plt.close(f)
