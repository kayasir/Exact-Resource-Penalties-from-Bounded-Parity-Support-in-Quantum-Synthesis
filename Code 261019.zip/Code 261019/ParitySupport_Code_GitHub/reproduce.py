"""Reproduce the exact calculations, compare reference data, and optionally plot.

Run from the extracted package: python reproduce.py --figures
The reference data are never overwritten. Fresh calculations run in a temporary
workspace; results and logs are saved under generated/ (or --output-dir).
"""
import argparse
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figures', action='store_true', help='regenerate all five figures')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'generated')
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        parser.error('Python 3.11 or newer is required.')
    if not __debug__:
        parser.error('Run without -O or PYTHONOPTIMIZE; exact assertions must remain enabled.')
    output = args.output_dir.resolve()
    # Avoid writing results over the reference archive or sources.
    if output == ROOT or output in [ROOT / 'data', ROOT / 'verification', ROOT / 'paper_sources']:
        parser.error('Choose a separate output directory, such as generated/.')
    output.mkdir(parents=True, exist_ok=True)
    logs = output / 'logs'
    logs.mkdir(exist_ok=True)
    report = {'status': 'running', 'utc_started': datetime.now(timezone.utc).isoformat(),
              'python': platform.python_version(), 'platform': platform.platform(),
              'dependencies': {}, 'steps': [], 'reference_data_unchanged': False}
    for package in ('numpy', 'matplotlib', 'Pillow'):
        try:
            report['dependencies'][package] = version(package)
        except Exception:
            parser.error(f'Missing dependency {package}; install requirements.txt first.')
    reference = {p.name: p.read_bytes() for p in (ROOT / 'data').glob('*.json')}
    started = time.perf_counter()
    try:
        with tempfile.TemporaryDirectory(prefix='parity_support_') as temp:
            work = Path(temp)
            shutil.copytree(ROOT / 'data', work / 'data')
            shutil.copytree(ROOT / 'verification', work / 'verification')
            paper = ROOT if (ROOT / 'Main.tex').is_file() else ROOT / 'paper_sources'
            for name in ('Main.tex', 'Supplement.tex'):
                shutil.copy2(paper / name, work / name)
            for name in ('plot_figures.py', 'schematic.py'):
                shutil.copy2(ROOT / name, work / name)

            def run(script, result_file=None, writes=(), extra=()):
                name = Path(script).stem
                print(f'Running {name} ...', flush=True)
                step_start = time.perf_counter()
                proc = subprocess.run([sys.executable, str(work / script), *map(str, extra)],
                                      cwd=work, text=True, encoding='utf-8', errors='replace',
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                (logs / (name + '.stdout.txt')).write_text(proc.stdout, encoding='utf-8')
                (logs / (name + '.stderr.txt')).write_text(proc.stderr, encoding='utf-8')
                if proc.returncode:
                    raise RuntimeError(f'{name} failed; see {logs / (name + ".stderr.txt")}')
                if result_file:
                    result = json.loads(proc.stdout)
                    (work / 'data' / result_file).write_text(json.dumps(result, indent=2) + '\n')
                comparisons = []
                for filename in (*writes, *((result_file,) if result_file else ())):
                    fresh = json.loads((work / 'data' / filename).read_text())
                    if filename in reference:
                        if fresh != json.loads(reference[filename]):
                            raise RuntimeError(f'{name}: regenerated {filename} differs from reference data')
                        comparisons.append(filename)
                report['steps'].append({'script': script, 'passed': True,
                                        'seconds': round(time.perf_counter()-step_start, 3),
                                        'reference_matches': comparisons})

            run('verification/verify_obstruction.py', 'obstruction_certificate.json')
            run('verification/verify_walsh.py', 'walsh_validation.json')
            run('verification/verify_affine.py', writes=('affine_certificates.json',))
            run('verification/verify_family.py', writes=('family_validation.json',))
            run('verification/verify_neighborhood.py', writes=('neighborhood_validation.json',))
            run('verification/verify_repair.py', 'repair_validation.json', ('repair_spectrum.json',))
            run('verification/verify_manuscript.py', 'manuscript_validation.json')
            run('verification/verify_math_parameters.py', 'math_parameter_validation.json')
            run('verification/verify_prl_package.py', 'prl_package_validation.json')
            if args.figures:
                run('plot_figures.py', extra=('--output-dir', output / 'figures'))
                run('schematic.py', extra=('--output-dir', output / 'figures'))
                expected = [f'{name}.{ext}' for name in ('Fig1','Fig2','Fig3','FigS1','FigS2')
                            for ext in ('pdf','eps','jpg')] + ['Fig1.svg']
                for filename in expected:
                    f = output / 'figures' / filename
                    if not f.is_file() or f.stat().st_size == 0:
                        raise RuntimeError(f'Missing figure output: {filename}')
                if 'figure_values.json' in reference:
                    assert json.loads((output / 'figures/figure_values.json').read_text()) == json.loads(reference['figure_values.json'])
                    report['plotted_values_match_reference'] = True
                report['figure_files'] = expected
            shutil.copytree(work / 'data', output / 'data', dirs_exist_ok=True)
        assert all((ROOT / 'data' / name).read_bytes() == contents
                   for name, contents in reference.items())
        report['reference_data_unchanged'] = True
        report['reference_sha256'] = {name: hashlib.sha256(data).hexdigest()
                                      for name, data in reference.items()}
        report['status'] = 'passed'
    except Exception as error:
        report['status'] = 'failed'
        report['error'] = str(error)
        raise
    finally:
        report['elapsed_seconds'] = round(time.perf_counter()-started, 3)
        (output / 'validation_report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'All checks passed. Results: {output}', flush=True)

if __name__ == '__main__':
    main()
