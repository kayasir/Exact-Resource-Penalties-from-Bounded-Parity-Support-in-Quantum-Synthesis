# Upload this code and data to GitHub

1. Extract `ParitySupport_Code_GitHub.zip`. Keep the folder structure intact.
2. Run `python reproduce.py --figures` as described in the README and confirm `All checks passed`.
3. Sign in to GitHub, choose **New repository**, and use a name such as `bounded-parity-support-synthesis`. Choose the visibility you intend; the manuscript link must be publicly accessible if readers are to reproduce the work.
4. In the new repository choose **Add file > Upload files**. Upload the extracted contents so that `README.md`, `reproduce.py`, `data/`, `verification/`, and `paper_sources/` appear at the repository root. Do not upload only the ZIP as a substitute for the browsable source files. Do not upload `.venv/` or the local `generated/` folder.
5. Review the file list and commit the files with a message such as `Add final manuscript reproducibility code and exact data`. The supplied reference data and validation report belong in the repository.
6. Copy the actual repository URL. Record the commit identifier for the version associated with the submitted paper. Add your chosen reuse license if you intend to permit reuse under that license.

The archive contains fewer than 100 files, each below GitHub's 25 MiB browser-upload limit. If using an existing repository with protected branches, follow that repository's branch and pull-request workflow.

## Paper availability statement after upload

Replace the current availability sentence in the main text and supplement with wording of this form, substituting the actual URL and commit identifier:

> The source code, exact certificate data, and reproduction instructions are available at [actual repository URL], at the commit associated with this manuscript [actual commit identifier]. No external experimental dataset was used.

Do not paste the bracketed example text into the submitted paper. The supplied paper currently refers to the accompanying reproducibility archive because no repository URL has yet been provided.

Official instructions checked 19 October 2026:

- https://docs.github.com/en/repositories/creating-and-managing-repositories/quickstart-for-repositories
- https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
