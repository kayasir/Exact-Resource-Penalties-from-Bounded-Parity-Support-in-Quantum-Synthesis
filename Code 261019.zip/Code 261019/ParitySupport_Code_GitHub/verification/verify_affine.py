import itertools,collections,json,math
from pathlib import Path
out=[]
for n in [4,8,16,32,64]:
 blocks=sorted({tuple(sorted((a,b,c,a^b^c))) for a,b,c in itertools.combinations(range(n),3)})
 triple=collections.Counter(t for b in blocks for t in itertools.combinations(b,3))
 pairs=collections.Counter(t for b in blocks for t in itertools.combinations(b,2))
 singles=collections.Counter(t for b in blocks for t in b)
 B=math.comb(n,3)//4;l2=(n-2)//2;l1=(n-1)*(n-2)//6
 assert len(blocks)==B and len(triple)==math.comb(n,3) and set(triple.values())=={1}
 assert len(pairs)==math.comb(n,2) and set(pairs.values())=={l2} and l2%2==1
 assert len(singles)==n and set(singles.values())=={l1} and l1%2==1
 e2=(1-l2)%4;e1=(1-l1-(n-1)*e2)%8
 assert (l2+e2-1)%4==0 and (l1+(n-1)*e2+e1-1)%8==0 and e1%2==e2%2==0
 if n<=8:
  for x in range(1<<n):
   val=sum(sum((x>>i)&1 for i in b)%2 for b in blocks)
   val+=e2*sum(((x>>i)^(x>>j))&1 for i,j in itertools.combinations(range(n),2))
   val+=e1*x.bit_count()
   assert val%8==x.bit_count()%2
 out.append({'n':n,'T4':B,'Tfull':1,'qstar':n,'pair_multiplicity':l2,'singleton_multiplicity':l1,'pair_correction':e2,'singleton_correction':e1,'constructed_full_CX':2*(n-1),'blocks':blocks})
 print(n,B,l1,l2,e1,e2,'verified',flush=True)
(Path(__file__).resolve().parents[1]/'data'/'affine_certificates.json').write_text(json.dumps(out))
