import itertools,json,math
from pathlib import Path
import numpy as np
# exact GF(2) code utilities, implemented independently of Mathematica

def ker(h):
 h=h.copy()%2;r=0;p=[]
 for j in range(h.shape[1]):
  nz=np.flatnonzero(h[r:,j])
  if not len(nz):continue
  k=r+nz[0];h[[r,k]]=h[[k,r]]
  for k in range(len(h)):
   if k!=r and h[k,j]:h[k]^=h[r]
  p.append(j);r+=1
  if r==len(h):break
 bs=[]
 for j in range(h.shape[1]):
  if j in p:continue
  v=np.zeros(h.shape[1],dtype=np.int64);v[j]=1
  for k,i in enumerate(p):v[i]=h[k,j]
  bs.append(v)
 return bs

def states(c,bs):
 z=np.array([c])
 for b in bs:z=np.concatenate((z,z^b))
 return z

def coeff(n):
 return np.array([([0,math.comb(n-2,2),3-n,1][a.bit_count()] if a.bit_count()<=3 else 0)%8 for a in range(1,2**n)],dtype=np.int64)
def t3(n):return math.comb(n,3)+((3-n)%2)*math.comb(n,2)+(math.comb(n-2,2)%2)*n
# Check the symmetric identity on every Hamming weight for n=3..128.
# Sum_{|S|=r} ell_S(x)= sum_{j odd} C(h,j) C(n-h,r-j).
def C(n,k):return math.comb(n,k) if 0<=k<=n else 0
for n in range(3,129):
 co={1:C(n-2,2),2:3-n,3:1}
 for h in range(n+1):
  value=sum(co[r]*sum(C(h,j)*C(n-h,r-j) for j in range(1,r+1,2)) for r in [1,2,3])
  assert (value-h%2)%8==0
 assert t3(n)>=C(n,3)
small=[]
for n in [4,5,6]:
 c=coeff(n);a=list(range(1,2**n));rows=[sum(1<<i for i in s) for r in [1,2,3] for s in itertools.combinations(range(n),r)]
 H=np.array([[int(mask&s==s) for mask in a] for s in rows]);assert np.all(H@c%2==1)
 ix=[i for i,mask in enumerate(a) if mask.bit_count()<=4];bs=ker(H[:,ix]);zs=states(c[ix]%2,bs)
 T4=int(zs.sum(axis=1).min());assert sum(c%2)==t3(n)
 assert T4>=math.ceil(C(n,3)/C(4,3));small.append({'n':n,'Tfull':1,'T3':t3(n),'T4':T4,'L4':math.ceil(C(n,3)/4)})
 print(small[-1],flush=True)
result={'identity_checked_n':[3,128],'identity_check':'Exact integer count on every Hamming weight; not a substitute for the algebraic proof','small_exact':small,
'family':[{'n':n,'T3':t3(n),'L4':math.ceil(C(n,3)/4),'Tfull':1,'constructed_CX':2*(n-1)} for n in range(4,65)]}
(Path(__file__).resolve().parents[1]/'data'/'family_validation.json').write_text(json.dumps(result,indent=2))
