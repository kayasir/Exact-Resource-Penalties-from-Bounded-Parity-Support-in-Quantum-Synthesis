"""Exact, dependency-free audit. Python 3.10+. Run: python verification/verify_obstruction.py.
All arithmetic is integer. Prints JSON; writes no files unless stdout redirected.
This finite enumeration is not a scalable compiler or a novelty proof.
"""
import itertools, json
N=6
INPUT={1:1,2:3,4:4,5:7,6:7,7:1,8:4,10:7,12:6,14:1,16:2,20:7,24:7,28:1,32:2,40:7,56:1}
A=list(range(1,1<<N));c=[INPUT.get(a,0) for a in A]
rows=[sum(1<<i for i in t) for k in (1,2,3) for t in itertools.combinations(range(N),k)]
def kernel(columns):
    r=[sum(1<<j for j,a in enumerate(columns) if a&t==t) for t in rows]
    piv=[];i=0
    for j in range(len(columns)):
        k=next((k for k in range(i,len(r)) if r[k]>>j&1),None)
        if k is None: continue
        r[i],r[k]=r[k],r[i]
        for k in range(len(r)):
            if k!=i and r[k]>>j&1:r[k]^=r[i]
        piv.append(j);i+=1
    basis=[]
    for j in range(len(columns)):
        if j not in piv:
            v=1<<j
            for k,p in enumerate(piv):
                if r[k]>>j&1:v|=1<<p
            basis.append(v)
    return basis,len(piv)
def audit(columns):
    assert all(a in columns for a,v in INPUT.items() if v%2)
    bs,rank=kernel(columns);z=sum((INPUT.get(a,0)%2)<<j for j,a in enumerate(columns))
    hist=[0]*(len(columns)+1);best=len(columns)+1;witnesses=[]
    for k in range(1<<len(bs)):
        if k:z^=bs[(k&-k).bit_length()-1]
        w=z.bit_count();hist[w]+=1
        if w<best:best=w;witnesses=[]
        if w==best:witnesses.append([a for j,a in enumerate(columns) if z>>j&1])
    assert sum(hist)==1<<len(bs)
    return dict(rank=rank,nullity=len(bs),minimum=best,histogram=hist,witnesses=witnesses)
def verify_and_lift(support):
    z=[int(a in support) for a in A]
    assert all(sum((ci-zi) for a,ci,zi in zip(A,c,z) if a&t==t)%2==0 for t in rows)
    lift=z.copy()
    for i,j in itertools.combinations(range(N),2):
        p=(1<<i)|(1<<j);delta=sum(ci-zi for a,ci,zi in zip(A,c,z) if a&p==p)%4
        assert delta%2==0;lift[p-1]+=delta
    for i in range(N):
        delta=sum(ci-zi for a,ci,zi in zip(A,c,lift) if a>>i&1)%8
        assert delta%2==0;lift[(1<<i)-1]+=delta
    lift=[v%8 for v in lift]
    assert sum(v%2 for v in lift)==len(support)
    for x in range(1<<N):assert sum((ci-zi)*((a&x).bit_count()%2) for a,ci,zi in zip(A,c,lift))%8==0
    return {a:v for a,v in zip(A,lift) if v}
full=audit(A);limited=audit([a for a in A if a.bit_count()<=4])
assert full['minimum']==10 and limited['minimum']==12
full['lifted_witness']=verify_and_lift(full['witnesses'][0]);limited['lifted_witness']=verify_and_lift(limited['witnesses'][0])
spans=[]
for p in itertools.permutations(range(N)):
    def span(a):
        pos=[p[i] for i in range(N) if a>>i&1];return max(pos)-min(pos)+1
    spans.append(min(max(map(span,z)) for z in full['witnesses']))
result=dict(n=N,input=INPUT,full=full,weight4=limited,
    min_max_support=min(max(a.bit_count() for a in z) for z in full['witnesses']),
    min_span_over_all_orderings=min(spans),max_span_over_all_orderings=max(spans),
    ordering_span_histogram={r:spans.count(r) for r in sorted(set(spans))},
    checks='Complete GF(2) coset enumeration; exact phase checks on all 64 basis inputs; all 720 orderings.')
print(json.dumps(result,indent=2))
