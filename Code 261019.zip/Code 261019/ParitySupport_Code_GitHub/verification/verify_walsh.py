"""Independent full-optimum audit using integer Walsh transforms, not nullspaces.
Run in the package directory: python verification/verify_walsh.py
Standard library only; reads the explicit input from data/obstruction_certificate.json.
"""
from pathlib import Path
import itertools,json
r=json.loads((Path(__file__).resolve().parents[1]/'data'/'obstruction_certificate.json').read_text())
c={int(k):v for k,v in r['input'].items()};n=6
f=[0]+[c.get(a,0)%2 for a in range(1,64)]
pairs=list(itertools.combinations(range(n),2))
generators=[[x for x in range(64) if x>>i&1 and x>>j&1] for i,j in pairs]
q=[0]*64;score=-1;witnesses=[]
for k in range(1<<len(pairs)):
    if k:
        for x in generators[(k&-k).bit_length()-1]:q[x]^=1
    w=[1-2*(f[x]^q[x]) for x in range(64)]
    half=1
    while half<64:
        for start in range(0,64,2*half):
            for j in range(start,start+half):
                a,b=w[j],w[j+half];w[j],w[j+half]=a+b,a-b
        half*=2
    for linear,correlation in enumerate(w):
        val=abs(correlation-1)
        if val<score:continue
        if val>score:score=val;witnesses=[]
        b=int(correlation-1<0)
        witnesses.append([x for x in range(1,64) if f[x]^q[x]^((linear&x).bit_count()%2)^b])
minimum=(63-score)//2
assert minimum==r['full']['minimum']
assert sorted(witnesses)==sorted(r['full']['witnesses'])
print(json.dumps(dict(method='integer quadratic enumeration and Walsh transform',
    punctured_correlation_max=score,minimum=minimum,optimal_odd_patterns=witnesses,
    matches_independent_kernel_enumeration=True),indent=2))
