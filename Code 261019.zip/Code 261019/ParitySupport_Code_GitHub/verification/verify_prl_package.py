"""Check the PRL sources, all data mappings, and schematic gate action."""
from pathlib import Path
import json,re,math,argparse
root=Path(__file__).resolve().parents[1]
for x in range(16):
 for c in range(8):
  bits=[(x>>i)&1 for i in range(4)];orig=bits[:]
  bits[3]^=bits[0];bits[3]^=bits[1]
  phase=c*bits[3]%8
  bits[3]^=bits[1];bits[3]^=bits[0]
  assert bits==orig and phase==c*(orig[0]^orig[1]^orig[3])%8
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--paper-dir',type=Path,default=root)
args=parser.parse_args()
paper=args.paper_dir
if not (paper/'Main.tex').is_file() and paper==root:
 paper=root/'paper_sources'
main=(paper/'Main.tex').read_text();sm=(paper/'Supplement.tex').read_text()
assert main.count(r'\begin{figure*}')==3
assert sm.count(r'\begin{figure}')==2
assert r'{revtex4-1}' in main and r'{revtex4-1}' in sm
assert 'twocolumn,english' in main and 'onecolumn,english' in sm
allkeys=set()
for name,s in [('Main',main),('Supplement',sm)]:
 keys=re.findall(r'\\bibitem\s*\[.*?\]\{([^}]+)\}|\\bibitem\{([^}]+)\}',s,re.S)
 keys=[a or b for a,b in keys];assert len(keys)==len(set(keys))==41
 used={k.strip() for cluster in re.findall(r'\\cite\{([^}]+)\}',s) for k in cluster.split(',')}
 assert used<=set(keys);allkeys|=used
 labels=re.findall(r'\\label\{([^}]+)\}',s);assert len(labels)==len(set(labels))
 refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',s);assert set(refs)<=set(labels)
 if name=='Main':mainkeys=keys
 else:assert keys==mainkeys
assert allkeys==set(mainkeys)
rows=json.loads((root/'data/neighborhood_validation.json').read_text())
assert len(rows)==30
assert [sum(r[4]>r[3] for r in rows if r[0]==n) for n in [4,5,6]]==[0,3,5]
assert max(r[6]/(r[4]-r[3]) for r in rows if r[4]>r[3])==24
for n in [4,8,16,32,64]:
 b=math.comb(n,3)//4;assert 4*b==math.comb(n,3)
# Read the actual typeset numerical table entries, not only the JSON files.
def table_rows(label):
 blocks=re.findall(r'\\begin\{table\}(.*?)\\end\{table\}',sm,re.S)
 block=next(b for b in blocks if r'\label{'+label+'}' in b)
 return [[int(v.strip()) for v in line.split('&')]
         for line in re.findall(r'^\s*([0-9 &]+)\\\\\s*$',block,re.M)]
assert table_rows('tab:all6')==[[r[2]]+r[3:] for r in rows if r[0]==6]
assert table_rows('tab:all45')==[[r[0],r[2]]+r[3:] for r in rows if r[0] in [4,5]]
assert table_rows('tab:population')==[[n]+[sum(r[4]-r[3]==g for r in rows if r[0]==n) for g in [0,1,2]]+[sum(r[5]==q for r in rows if r[0]==n) for q in [3,4,5]] for n in [4,5,6]]
ob=json.loads((root/'data/obstruction_certificate.json').read_text())
assert table_rows('tab:histogram')==[[w,ob['full']['histogram'][w],ob['weight4']['histogram'][w]] for w in range(10,15)]
for label,expected in [('eq:inputmasks',ob['input']),('eq:finlift',ob['full']['lifted_witness'])]:
 block=next(b for b in re.findall(r'\\begin\{align\}(.*?)\\end\{align\}',sm,re.S) if r'\label{'+label+'}' in b)
 pairs=dict(re.findall(r'(\d+):(\d+)',block))
 assert pairs=={str(a):str(c) for a,c in expected.items()}
print(json.dumps({'schematic_exact_all_128_input_coefficient_pairs':True,
 'main_figures':3,'supplement_figures':2,'bibliography_entries':41,
 'cross_references_valid':True,'all_30_population_records_checked':True,
 'all_four_numerical_tables_match_certificates':True,
 'printed_input_and_lifted_coefficients_match':True},indent=2))
