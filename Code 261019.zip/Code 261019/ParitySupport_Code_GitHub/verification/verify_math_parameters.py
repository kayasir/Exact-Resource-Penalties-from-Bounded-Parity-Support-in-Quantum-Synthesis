"""Check the polynomial targets, modular lift and numerical parameter ranges.

This check evaluates the polynomial in the paper directly, independently of
the parity-expansion construction used by the neighborhood enumerator.
"""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
import json
import math

root = Path(__file__).resolve().parents[1]
record = json.loads((root / 'data/obstruction_certificate.json').read_text())
inputs = {int(a): c for a, c in record['input'].items()}

def polynomial(n, x, extra=0):
    bits = [(x >> i) & 1 for i in range(n)]
    phase = 4 * sum(bits[i] * bits[i+1] * bits[i+2] for i in range(n-2))
    phase += sum(bits[i-1] for i in (2, 3, 4, 6) if i <= n)
    phase += sum(bits[i-1] ^ bits[j-1]
                 for i, j in ((1, 2), (2, 3), (4, 5), (5, 6)) if j <= n)
    return (phase + (extra & x).bit_count() % 2) % 8

def parity_phase(coefficients, x):
    return sum(c * ((a & x).bit_count() % 2)
               for a, c in coefficients.items()) % 8

for x in range(64):
    assert polynomial(6, x) == parity_phase(inputs, x)
for name in ('full', 'weight4'):
    lifted = {int(a): c for a, c in record[name]['lifted_witness'].items()}
    assert sum(c % 2 for c in lifted.values()) == record[name]['minimum']
    if name == 'weight4':
        assert all(a.bit_count() <= 4 for a in lifted)
    for degree, modulus in ((1, 8), (2, 4), (3, 2)):
        for subset in combinations(range(6), degree):
            mask = sum(1 << i for i in subset)
            lhs = sum(c for a, c in inputs.items() if a & mask == mask)
            rhs = sum(c for a, c in lifted.items() if a & mask == mask)
            assert (lhs - rhs) % modulus == 0
    assert all(polynomial(6, x) == parity_phase(lifted, x) for x in range(64))

records = json.loads((root / 'data/neighborhood_validation.json').read_text())
population_checks = 0
for n in (4, 5, 6):
    rows = [r for r in records if r[0] == n]
    masks = [0] + [1 << i for i in range(n)] + [3 << i for i in range(n-1)]
    assert [r[2] for r in rows] == masks and len(rows) == 2*n
    # Boolean Mobius inversion obtains the weighted polynomial coefficients.
    for extra in masks:
        truth = [polynomial(n, x, extra) for x in range(1 << n)]
        coefficients = truth.copy()
        for i in range(n):
            for x in range(1 << n):
                if (x >> i) & 1:
                    coefficients[x] = (coefficients[x] - coefficients[x ^ (1 << i)]) % 8
        assert coefficients[0] == 0
        assert all(v == 0 for a, v in enumerate(coefficients) if a.bit_count() > 3)
        assert all(v % (1 << (a.bit_count()-1)) == 0
                   for a, v in enumerate(coefficients) if a)
        population_checks += 1

affine = json.loads((root / 'data/affine_certificates.json').read_text())
assert [r['n'] for r in affine] == [4, 8, 16, 32, 64]
for r in affine:
    n = r['n']
    assert r['T4'] == math.comb(n, 3) // 4
    assert r['Tfull'] == 1 and r['qstar'] == n
    assert r['constructed_full_CX'] == 2*(n-1)
assert Fraction(14, 15) < 1
assert Fraction(140, 31) > 1
assert Fraction(24, 12-10) == 12
thresholds = {str(n): sorted(str(Fraction(r[6], r[4]-r[3]))
              for r in records if r[0] == n and r[4] > r[3]) for n in (4, 5, 6)}
assert thresholds == {'4': [], '5': ['10', '20', '20'], '6': ['12', '12', '24', '24', '24']}
print(json.dumps({'direct_polynomial_basis_inputs': 64,
                  'exact_lift_moduli': [8, 4, 2],
                  'neighborhood_target_polynomials': population_checks,
                  'affine_sizes': [r['n'] for r in affine],
                  'relative_T_costs_in_analytic_plot': [0.1, 1, 10],
                  'finite_cost_plot_range': [0, 40],
                  'strict_thresholds': thresholds,
                  'checks_passed': True}, indent=2))
