import numpy as np,itertools,json
from pathlib import Path

def ker(h):
 h=h.copy()%2;r=0;p=[]
 for j in range(h.shape[1]):
  nz=np.flatnonzero(h[r:,j])
  if not len(nz):continue
  k=r+nz[0];h[[r,k]]=h[[k,r]]
  for k in range(len(h)):
   if k!=r and h[k,j]:h[k]^=h[r]
  p.append(j);r+=1
  if r==len(h):break
 bs=[]
 for j in range(h.shape[1]):
  if j in p:continue
  v=np.zeros(h.shape[1],dtype=np.int64);v[j]=1
  for k,i in enumerate(p):v[i]=h[k,j]
  bs.append(v)
 return bs

def states(c,bs):
 z=np.array([c])
 for b in bs:z=np.concatenate((z,z^b))
 return z

def base(n):
 c=np.zeros(2**n-1,np.int64)
 for i in range(n-2):
  for k in range(1,4):
   for s in itertools.combinations(range(i,i+3),k):c[sum(1<<j for j in s)-1]+=(-1)**(k+1)
 for j in [2,3,4,6]:
  if j<=n:c[(1<<(j-1))-1]+=1
 for i,j in [(1,2),(2,3),(4,5),(5,6)]:
  if j<=n:c[(1<<(i-1))+(1<<(j-1))-1]+=1
 return c%8

def lift(c,z,n):
 out=z.copy()
 for i,j in itertools.combinations(range(n),2):
  p=(1<<i)|(1<<j);d=sum(int(c[a-1]-z[a-1]) for a in range(1,2**n) if a&p==p)%4
  assert d%2==0;out[p-1]+=d
 for i in range(n):
  d=sum(int(c[a-1]-out[a-1]) for a in range(1,2**n) if a>>i&1)%8
  assert d%2==0;out[(1<<i)-1]+=d
 out%=8
 for x in range(2**n):assert sum(int(c[a-1]-out[a-1])*((a&x).bit_count()%2) for a in range(1,2**n))%8==0
 return out

def route(c,n):
 best=10**6
 for mode in range(3):
  gates=[]
  for t in range(n):
   rem=[a for a in range(1,2**n) if c[a-1] and a.bit_length()-1==t];cur=1<<t
   while rem:
    nxt=rem[0] if mode==0 else rem[-1] if mode==1 else min(rem,key=lambda a:((cur^a).bit_count(),a))
    for j in range(n):
     if (cur^nxt)>>j&1:gates.append(('CX',j,t))
    gates.append(('P',t,int(c[nxt-1])));cur=nxt;rem.remove(nxt)
   for j in range(n):
    if (cur^(1<<t))>>j&1:gates.append(('CX',j,t))
  wires=[1<<i for i in range(n)];acc=[0]*(2**n-1)
  for typ,a,b in gates:
   if typ=='CX':wires[b]^=wires[a]
   else:acc[wires[a]-1]+=b
  assert wires==[1<<i for i in range(n)] and all((a-b)%8==0 for a,b in zip(acc,c))
  best=min(best,sum(g[0]=='CX' for g in gates))
 return best
res=[]
for n in [4,5,6]:
 bits=((np.arange(2**n)[:,None]>>np.arange(n))&1).astype(np.int16)
 masks=list(range(1,2**n));rows=[sum(1<<i for i in p) for k in [1,2,3] for p in itertools.combinations(range(n),k)]
 H=np.array([[int(a&t==t) for a in masks] for t in rows]);ix=[a-1 for a in masks if a.bit_count()<=4]
 k=ker(H[:,ix]);q=np.ones((1,2**n),np.int16)
 if n==6:
  for i,j in itertools.combinations(range(n),2):q=np.concatenate((q,q*(1-2*bits[:,i]*bits[:,j])))
 w=np.ones((2**n,1),np.int16) if n==4 else 1-2*(bits@bits.T%2)
 for ordinal,toggle in enumerate([0]+[1<<i for i in range(n)]+[(1<<i)|(1<<(i+1)) for i in range(n-1)]):
  c=base(n)
  if toggle:c[toggle-1]=(c[toggle-1]+1)%8
  v=1-2*np.r_[0,c%2]
  corr=(q*v.astype(np.int16))@w;score=np.abs(corr-1).max();opt=(len(c)-int(score))//2
  witnesses=[]
  for i,j in np.argwhere(abs(corr-1)==score):witnesses.append((np.r_[0,c%2]+(1-q[i])//2+(1-w[:,j])//2+int(corr[i,j]-1<0))[1:]%2)
  witnesses=np.unique(witnesses,axis=0)
  assert all(np.all(H@(z-c)%2==0) and sum(z)==opt for z in witnesses)
  qstar=min(max(a.bit_count() for a,zv in zip(masks,z) if zv) for z in witnesses)
  restricted=int(states(c[ix]%2,k).sum(axis=1).min())
  cx=min(route(lift(c,z,n),n) for z in witnesses)
  row=[n,ordinal,toggle,opt,restricted,qstar,cx,len(witnesses)]
  res.append(row);print(row,flush=True)
assert res[18][0:5]==[6,0,0,10,12] and res[18][6]==24
(Path(__file__).resolve().parents[1]/'data'/'neighborhood_validation.json').write_text(json.dumps(res))
