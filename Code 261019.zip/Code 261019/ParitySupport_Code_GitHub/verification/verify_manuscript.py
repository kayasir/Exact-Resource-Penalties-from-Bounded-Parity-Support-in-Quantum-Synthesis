"""Verify manuscript-specific tables and the explicit 24-CNOT construction.
Run from any directory with Python 3.10+. Standard library only.
"""
from pathlib import Path
import json,collections,math
root=Path(__file__).resolve().parents[1]
r=json.loads((root/'data/obstruction_certificate.json').read_text())
c={int(k):v for k,v in r['full']['lifted_witness'].items()}
tours=[[1],[2],[4,6,7,4],[8,9,13,12,10,8],
       [16,20,23,19,27,31,24,16],[32,40,56,32]]
wires=[1<<i for i in range(6)];acc=collections.Counter();cx=0
for t,tour in enumerate(tours):
 assert tour[0]==tour[-1]==1<<t
 current=1<<t;done=set()
 for nxt in tour:
  for j in range(6):
   if (current^nxt)>>j&1:
    assert j<t
    wires[t]^=wires[j];cx+=1
  assert wires[t]==nxt
  if nxt not in done and nxt in c:acc[nxt]+=c[nxt];done.add(nxt)
  current=nxt
assert cx==24 and wires==[1<<i for i in range(6)]
assert dict(acc)==c
inp={int(k):v for k,v in r['input'].items()}
for x in range(64):
 assert sum((inp.get(a,0)-acc[a])*((a&x).bit_count()%2) for a in range(1,64))%8==0
rows=json.loads((root/'data/neighborhood_validation.json').read_text())
counts={}
for n in [4,5,6]:
 rr=[r for r in rows if r[0]==n]
 counts[n]={'gap':dict(collections.Counter(r[4]-r[3] for r in rr)),
            'support':dict(collections.Counter(r[5] for r in rr))}
assert counts[6]['support']=={3:4,4:3,5:5}
assert [sum(r[4]>r[3] for r in rows if r[0]==n) for n in [4,5,6]]==[0,3,5]
assert sorted(r[6]/(r[4]-r[3]) for r in rows if r[0]==5 and r[4]>r[3])==[10,20,20]
assert sorted(r[6]/(r[4]-r[3]) for r in rows if r[0]==6 and r[4]>r[3])==[12,12,24,24,24]
for n in range(4,1000):
 if n%12 in [4,8]:
  assert math.comb(n,3)%4==0
  assert ((n-2)//2)%2==1 and ((n-1)*(n-2)//6)%2==1
print(json.dumps({'explicit_witness_CNOTs':cx,'exact_phase_check':True,
 'neighborhood_counts':counts,'strict_thresholds_verified':True,
 'design_congruences_checked_through':999},indent=2))
