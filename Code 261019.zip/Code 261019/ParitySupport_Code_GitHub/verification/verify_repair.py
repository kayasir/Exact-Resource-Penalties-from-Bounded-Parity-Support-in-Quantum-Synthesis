"""Regenerate Fig. 3(c) by enumerating every support-four output.

Uses integer bit vectors and independent GF(2) row reduction. All 2^15
restricted outputs are enumerated; no numerical optimization is used.
"""
from pathlib import Path
from itertools import combinations
import json

root = Path(__file__).resolve().parents[1]
record = json.loads((root / 'data/obstruction_certificate.json').read_text())
n = record['n']
columns = [a for a in range(1, 1 << n) if a.bit_count() <= 4]
row_masks = [sum(1 << i for i in s)
             for size in (1, 2, 3) for s in combinations(range(n), size)]
matrix = [sum(1 << j for j, a in enumerate(columns) if a & s == s)
          for s in row_masks]
pivots = []
for col in range(len(columns)):
    rank = len(pivots)
    pivot = next((i for i in range(rank, len(matrix))
                  if (matrix[i] >> col) & 1), None)
    if pivot is None:
        continue
    matrix[rank], matrix[pivot] = matrix[pivot], matrix[rank]
    for i in range(len(matrix)):
        if i != rank and (matrix[i] >> col) & 1:
            matrix[i] ^= matrix[rank]
    pivots.append(col)
basis = []
for col in range(len(columns)):
    if col not in pivots:
        vector = 1 << col
        for i, pivot in enumerate(pivots):
            if (matrix[i] >> col) & 1:
                vector |= 1 << pivot
        basis.append(vector)
assert len(pivots) == 41 and len(basis) == 15

target = {int(a): c for a, c in record['input'].items()}
optimal = set(record['full']['witnesses'][0])
signature = [sum(c for a, c in target.items() if a & s == s) % 2
             for s in row_masks]
z = sum((target.get(a, 0) % 2) << j for j, a in enumerate(columns))
minimum_by_weight = {}
best = None
for step in range(1 << len(basis)):
    if step:
        z ^= basis[(step & -step).bit_length() - 1]
    output = {a for j, a in enumerate(columns) if (z >> j) & 1}
    correction = optimal ^ output
    removed, added = optimal - output, output - optimal
    weight, penalty = len(correction), len(output) - len(optimal)
    assert penalty == weight - 2 * len(removed)
    assert all(sum(a & s == s for a in correction) % 2 == 0 for s in row_masks)
    minimum_by_weight[weight] = min(minimum_by_weight.get(weight, penalty), penalty)
    if best is None or (penalty, weight, sorted(output)) < best[:3]:
        best = (penalty, weight, sorted(output), sorted(removed), sorted(added))
assert min(minimum_by_weight.values()) == 2
assert best[:2] == (2, 16) and len(best[3]) == 7 and len(best[4]) == 9
assert all(sum(a & s == s for a in best[2]) % 2 == t
           for s, t in zip(row_masks, signature))
spectrum = sorted([weight, penalty] for weight, penalty in minimum_by_weight.items())
(root / 'data/repair_spectrum.json').write_text(json.dumps(spectrum) + '\n')
print(json.dumps({'restricted_outputs_checked': 1 << len(basis),
                  'minimum_penalty': best[0], 'correction_weight': best[1],
                  'optimal_restricted_output': best[2],
                  'removed_masks': best[3], 'added_masks': best[4],
                  'all_kernel_checks_passed': True}, indent=2))
