"""Reproduce all numerical figures from exact stored certificates/formulas."""
from pathlib import Path
import json,math,collections,argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.ticker import MaxNLocator
R=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=R)
args=parser.parse_args()
OUT=args.output_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'serif','font.serif':['Nimbus Roman','Times New Roman','DejaVu Serif'],'mathtext.fontset':'stix','font.size':9,'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':8,'axes.linewidth':.9,'lines.linewidth':1.5,'lines.markersize':4,'pdf.fonttype':42,'ps.fonttype':3,'savefig.facecolor':'white'})
blue='#2459A6';teal='#008D80';orange='#DF6C18';purple='#8652AD';ink='#20354B'
data=json.loads((R/'data/obstruction_certificate.json').read_text());aff=json.loads((R/'data/affine_certificates.json').read_text());nb=np.array(json.loads((R/'data/neighborhood_validation.json').read_text()));repair=np.array(json.loads((R/'data/repair_spectrum.json').read_text()))
base_row=next(row for row in nb if row[0]==6 and row[2]==0)
full_T,restricted_T,witness_CX=map(int,[base_row[3],base_row[4],base_row[6]])
strict_threshold=witness_CX/(restricted_T-full_T)
def panel(ax,t):ax.text(-.16,1.05,'('+t+')',transform=ax.transAxes,fontsize=11,fontweight='bold',ha='left',va='bottom')
def legend(ax,**kw):return ax.legend(framealpha=.5,facecolor='white',edgecolor='#AAB5C0',borderpad=.25,labelspacing=.2,handlelength=1.35,**kw)
def finish(f,name):
 for ext in ['pdf','eps']:f.savefig(OUT/(name+'.'+ext))
 f.savefig(OUT/(name+'.jpg'),dpi=600,pil_kwargs={'quality':96})
 f.savefig(OUT/(name+'_preview.png'),dpi=165)
 plt.close(f)
def layout(rows,cols,height):
 f,axs=plt.subplots(rows,cols,figsize=(7.1,height));f.subplots_adjust(left=.082,right=.985,bottom=.14 if rows==1 else .12,top=.92,wspace=.42 if cols==2 else .46,hspace=.5);return f,np.ravel(axs)
n=np.array([4,8,16,32,64]);b=np.array([math.comb(int(x),3)//4 for x in n]);t3=np.array([math.comb(int(x),3)+((3-int(x))%2)*math.comb(int(x),2)+(math.comb(int(x)-2,2)%2)*int(x) for x in n])
f,a=layout(2,2,3.55)
blocks=next(r['blocks'] for r in aff if r['n']==8);mat=np.zeros((8,len(blocks)),int)
for j,bl in enumerate(blocks):mat[bl,j]=1
ax=a[0];ax.pcolormesh(np.arange(.5,15),np.arange(.5,9),mat,cmap=ListedColormap(['white',teal]),shading='flat');ax.set_ylim(8.5,.5);ax.set(xlabel='Block index',ylabel='Input wire',xticks=[1,4,7,10,14],yticks=[1,4,8]);ax.set_xticks(np.arange(.5,15),minor=True);ax.set_yticks(np.arange(.5,9),minor=True);ax.grid(which='minor',color='#DFE5E9',lw=.4);ax.tick_params(which='minor',length=0)
ax=a[1]
for y,c,m,l in [(t3,blue,'o',r'$T_3$'),(b,orange,'s',r'$T_4$'),(np.ones(5),teal,'D',r'$T_*^{\rm ph}$')]:ax.plot(n,y,color=c,marker=m,label=l)
ax.set_xscale('log',base=2);ax.set_yscale('log');ax.set(xlabel='Qubits $n$',ylabel='$T$ count',xticks=n,xticklabels=n);legend(ax,loc='upper left',ncol=3,columnspacing=.6)
ax=a[2];rho_c=2*(n[1:]-1)/(b[1:]-1);ax.plot(n[1:],rho_c,'o-',color=purple);ax.set_xscale('log',base=2);ax.set_yscale('log');ax.set(xlabel='Qubits $n$',ylabel=r'Threshold $\rho_c$',xticks=n[1:],xticklabels=n[1:]);ax.set_ylim(.006,2)
ax=a[3]
for rho,c,m in [(.1,purple,'s'),(1,blue,'o'),(10,teal,'^')]:ax.plot(n,rho*b/(rho+2*(n-1)),color=c,marker=m,label=rf'$\rho={rho:g}$')
ax.axhline(1,c='#7A8791',ls=':',lw=1);ax.set_xscale('log',base=2);ax.set_yscale('log');ax.set(xlabel='Qubits $n$',ylabel=r'Cost-ratio bound $R_n$',xticks=n,xticklabels=n);legend(ax,loc='upper left',ncol=1)
for ax,l in zip(a,'abcd'):panel(ax,l)
finish(f,'Fig2')
# Finite obstruction: six panels, all directly tied to complete certificates.
f,a=layout(2,3,4.05);f.subplots_adjust(left=.085,bottom=.12,top=.92,wspace=.43,hspace=.5)
ax=a[0];x=np.arange(10,15);ax.bar(x-.18,[data['full']['histogram'][i] for i in x],width=.35,color=teal,label='Full');ax.bar(x+.18,[data['weight4']['histogram'][i] for i in x],width=.35,color=orange,label=r'$k=4$');ax.set(xlabel='Odd-pattern weight',ylabel='Multiplicity',xticks=x,ylim=(0,22));legend(ax,loc='upper left');ax.yaxis.set_major_locator(MaxNLocator(integer=True,nbins=4))
ax=a[1];masks=data['full']['witnesses'][0];mat=np.zeros((6,10),int)
for j,m in enumerate(masks):
 for i in range(6):mat[i,j]=(2 if m==31 else 1) if m>>i&1 else 0
ax.pcolormesh(np.arange(.5,11),np.arange(.5,7),mat,cmap=ListedColormap(['white',teal,orange]),vmin=0,vmax=2,shading='flat');ax.set_ylim(6.5,.5);ax.set(xlabel='Parity index',ylabel='Input wire',xticks=[1,4,8,10],yticks=[1,3,6]);ax.text(8,0.45,'31',color=orange,ha='center',va='bottom',fontsize=8);ax.set_xticks(np.arange(.5,11),minor=True);ax.set_yticks(np.arange(.5,7),minor=True);ax.grid(which='minor',c='#DCE4E7',lw=.4);ax.tick_params(which='minor',length=0)
ax=a[2];ax.plot(repair[:,0],repair[:,1],'o',color=blue,ms=3.5);ax.scatter([16],[2],color=orange,s=30,zorder=4);ax.annotate('minimum = 2',(16,2),(16.5,16),fontsize=8,color=orange,arrowprops={'arrowstyle':'-','color':orange,'lw':.7});ax.set(xlabel='Correction weight',ylabel=r'$T$ penalty',xticks=[15,25,35,40],ylim=(0,24));ax.yaxis.set_major_locator(MaxNLocator(integer=True,nbins=4))
ax=a[3];rho=np.linspace(0,40,200);ax.plot(rho,restricted_T*rho,color=orange,label=r'$12\rho$');ax.plot(rho,full_T*rho+witness_CX,color=teal,label=r'$10\rho+24$');ax.plot(strict_threshold,restricted_T*strict_threshold,'o',c=ink,ms=3);ax.axvline(strict_threshold,c='#8394A1',ls=':',lw=.8);ax.set(xlabel=r'Relative $T$ cost $\rho$',ylabel='Logical cost',xticks=[0,12,24,40],ylim=(0,510));legend(ax,loc='upper left')
ax=a[4];rr=nb[nb[:,0]==6];idx=np.arange(12)
for j,row in enumerate(rr):ax.plot([j,j],[row[3],row[4]],c='#71808A',lw=.7)
ax.plot(idx-.10,rr[:,3],'o',c=teal,label='Full',ms=3.3);ax.plot(idx+.10,rr[:,4],'s',c=orange,label=r'$k=4$',ms=3.1);ax.set(xlabel='Added parity mask $d$',ylabel='$T$ count',xticks=idx,xticklabels=rr[:,2],ylim=(8.5,13.7),yticks=[9,10,11,12]);ax.tick_params(axis='x',labelsize=7.3,rotation=50);legend(ax,loc='upper left',ncol=2,columnspacing=.7,fontsize=7.5)
ax=a[5]
for N,col in [(4,blue),(5,orange),(6,teal)]:
 r=nb[nb[:,0]==N];gap=r[:,4]-r[:,3];thresholds=sorted(set(float(row[6]/(row[4]-row[3])) for row in r if row[4]>row[3]));edges=[0]+thresholds+[40];val=0
 for j in range(len(edges)-1):
  left,right=edges[j:j+2];mid=(left+right)/2;val=sum(mid*gap>r[:,6])/len(r);ax.plot([left,right],[val,val],c=col,label=f'$n={N}$' if j==0 else None)
  if j>0:ax.plot(left,val,'o',mfc='white',mec=col,ms=3.5,zorder=5)
  if j<len(edges)-2:ax.plot(right,val,'o',mfc=col,mec=col,ms=3.5,zorder=6)
ax.set(xlabel=r'Relative $T$ cost $\rho$',ylabel='Certified fraction',xticks=[0,12,24,40],ylim=(-.025,.52),yticks=[0,.2,.4]);legend(ax,loc='upper left',ncol=1,fontsize=7.5)
for ax,l in zip(a,'abcdef'):panel(ax,l)
finish(f,'Fig3')
# Additional diagnostics, preserving all panels from the previous article.
f,a=layout(2,2,3.55);fam=json.loads((R/'data/family_validation.json').read_text());ns=np.array([r['n'] for r in fam['family']]);lo=np.array([r['L4'] for r in fam['family']]);up=np.array([r['T3'] for r in fam['family']])
ax=a[0];ax.plot(ns,lo,c=orange,label='Cubic lower bound');ax.plot(ns,up,c=blue,label=r'$T_3$ upper bound');ax.plot([r['n'] for r in fam['small_exact']],[r['T4'] for r in fam['small_exact']],'D',c=teal,label='Exact small $n$');ax.set_yscale('log');ax.set(xlabel='Qubits $n$',ylabel=r'Bounds on $T_4$',xticks=[4,16,32,48,64]);legend(ax,loc='lower right',fontsize=7.5)
ax=a[1];ax.plot(n,n,'o-',c=orange,label='Original variables');ax.plot(n,np.ones(5),'s-',c=teal,label='After conjugation');ax.set(xlabel='Qubits $n$',ylabel=r'Required support $q_*$',xticks=n);legend(ax,loc='upper left',fontsize=7.5)
ax=a[2];ax.plot(n[1:],1-(1+2*(n[1:]-1))/b[1:],'o-',c=teal);ax.axhline(0,c='#85919A',ls=':',lw=.8);ax.set(xlabel='Qubits $n$',ylabel=r'Saving bound ($\rho=1$)',xticks=n[1:],ylim=(-.1,1.05))
ax=a[3];spans=sorted((int(k),v) for k,v in data['ordering_span_histogram'].items());ax.bar([k for k,v in spans],[v for k,v in spans],color=[purple,blue],width=.5);ax.set(xlabel='Maximum span',ylabel='Wire orderings',xticks=[k for k,v in spans],ylim=(0,660))
for span,count in spans:ax.text(span,count+19,str(count),ha='center')
for ax,l in zip(a,'abcd'):panel(ax,l)
finish(f,'FigS1')
f,a=layout(1,2,2.15)
for j,(q,col) in enumerate([(0,blue),(1,orange),(2,teal)]):
 counts=[sum(nb[nb[:,0]==N,4]-nb[nb[:,0]==N,3]==q) for N in [4,5,6]];a[0].bar(np.arange(3)+(j-1)*.23,counts,.22,color=col,label=rf'$\Delta_4={q}$')
for j,(q,col) in enumerate([(3,blue),(4,orange),(5,teal)]):
 counts=[sum(nb[nb[:,0]==N,5]==q) for N in [4,5,6]];a[1].bar(np.arange(3)+(j-1)*.23,counts,.22,color=col,label=rf'$q_*={q}$')
for ax,l in zip(a,'ab'):
 ax.set(xlabel='Qubits $n$',ylabel='Target count',xticks=np.arange(3),xticklabels=[4,5,6],ylim=(0,10.5));ax.yaxis.set_major_locator(MaxNLocator(integer=True,nbins=4));legend(ax,loc='upper center',ncol=3,columnspacing=.5,fontsize=7.5);panel(ax,l)
finish(f,'FigS2')

# Machine-readable values for the plotted observables (all derived from records).
plot_values={
 'Fig2': {'a_blocks':blocks, 'b':{'n':n.tolist(),'T3':t3.tolist(),'T4':b.tolist(),'Tfull':[1]*len(n)},
          'c':{'n':n[1:].tolist(),'rho_c':rho_c.tolist()},
          'd':{str(r): (r*b/(r+2*(n-1))).tolist() for r in [0.1,1,10]}},
 'Fig3': {'a':{k:[data[k]['histogram'][w] for w in range(10,15)] for k in ['full','weight4']},
          'b_masks':data['full']['witnesses'][0], 'c':repair.tolist(),
          'd':{'rho_range':[0,40],'points':200,'restricted_T':restricted_T,'full_T':full_T,'witness_CX':witness_CX,'strict_threshold':strict_threshold},
          'e':nb[nb[:,0]==6].tolist(),
          'f':{str(N):{'population':int(sum(nb[:,0]==N)),
                      'strict_thresholds':[float(row[6]/(row[4]-row[3])) for row in nb if row[0]==N and row[4]>row[3]]} for N in [4,5,6]}},
 'FigS1':{'a':fam, 'b':{'n':n.tolist(),'original':n.tolist(),'conjugated':[1]*len(n)},
           'c':(1-(1+2*(n[1:]-1))/b[1:]).tolist(),'d':data['ordering_span_histogram']},
 'FigS2':{str(N):{'gap_counts':[int(sum(nb[nb[:,0]==N,4]-nb[nb[:,0]==N,3]==q)) for q in [0,1,2]],
                  'support_counts':[int(sum(nb[nb[:,0]==N,5]==q)) for q in [3,4,5]]} for N in [4,5,6]}}
(OUT/'figure_values.json').write_text(json.dumps(plot_values,indent=2)+'\n')
