# Bounded parity support in quantum synthesis

Reproducibility code for **Exact Resource Penalties from Bounded Parity Support in Quantum Synthesis**, Kashif Ammar Yasir, manuscript revision 19 October 2026.

This repository reproduces the exact certificates and all five figures. It uses integer GF(2), modulo-eight, and Walsh calculations for certification. Floating-point arithmetic is used only to display formula-based curves. No fitting, sampling, experimental data, network service, or solver license is required.

## Run on Windows

Install Python 3.12 and extract this archive. Open PowerShell in the folder containing `reproduce.py`, then run:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe reproduce.py --figures
```

Using the environment's Python executable directly avoids activation-policy issues. If Python is already on your path and a separate environment is unnecessary:

```powershell
python -m pip install -r requirements.txt
python reproduce.py --figures
```

## Run on Linux or macOS

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python reproduce.py --figures
```

Python 3.11 or newer is required by the pinned dependencies. The full calculation and plotting run was validated on Linux with Python 3.12.14 and the versions in `requirements.txt`. Windows commands and portable paths are supplied; native Windows execution was not available for this audit.

## Outputs

A successful run ends with `All checks passed` and creates:

- `generated/validation_report.json`: each check, its reference-data comparisons, environment, and elapsed times.
- `generated/data/`: freshly regenerated exact certificates.
- `generated/figures/`: all figures as vector EPS/PDF and 600-dpi JPG, Fig. 1 as SVG, four PNG previews, and `figure_values.json` with plotted values.
- `generated/logs/`: standard output and error logs for every script.

The runner works in a temporary directory and leaves `data/` unchanged. It fails if any regenerated reference value differs. `python reproduce.py` runs all exact checks without generating figures. `--output-dir PATH` changes the output destination. Run without Python's `-O` option: assertions are part of the exact verification.

The full run is a small finite calculation; its recorded execution time is a reproducibility diagnostic, not a compiler-performance claim. The proof covers arbitrary admissible sizes; the numerical checks cover the finite ranges listed below.

## Expected results

| Quantity | Reference result |
| --- | --- |
| Six-wire unrestricted and support-four minima | 10 and 12 T gates |
| Full and restricted enumeration sizes | 4,194,304 and 32,768 odd patterns |
| Independent punctured Walsh maximum | 43 |
| Unique unrestricted odd masks | 7, 9, 13, 16, 19, 23, 27, 31, 40, 56 |
| Minimum repair penalty | 2, with correction weight 16: remove 7 masks, add 9 |
| Explicit unrestricted witness | 10 T gates and 24 CNOTs; exact on all 64 inputs |
| Strict weighted advantage for the base target | Relative T cost greater than 12 |
| Complete neighborhood | 30 targets; positive gaps in 0/8, 3/10, 5/12 cases |
| Affine support-four counts at n = 4, 8, 16, 32, 64 | 1, 14, 140, 1240, 10416 |

## Model and parameter conventions

- Ancilla-free diagonal CNOT plus powers of T; no Hadamards, measurements, or postselection.
- Phase is `exp(i*pi*p(x)/4)`, with coefficients modulo eight. One-qubit Clifford phases are free.
- A mask is `sum(2**(i-1) for i in S)`: wire 1 is the least significant bit. Support is the number of set bits in fixed input coordinates.
- Restricted support cap: four. It is not a hardware connectivity or interval-span constraint.
- Weighted logical objective: `rho*T + CNOT`, with arbitrary CNOT connectivity. Thresholds certify strict advantage only above the indicated value.
- Analytic figure sizes: 4, 8, 16, 32, 64. General bounds: every integer 4 through 64. Identity checks: every Hamming weight for 3 through 128 wires.
- Finite population sizes: 4, 5, 6, with the base target, each singleton addition, and each nearest-neighbor parity addition, in that order.
- Analytic cost ratios: rho = 0.1, 1, 10. Finite cost curves: 200 display points on [0, 40]; threshold fractions use exact strict inequalities.

See `MATH_AND_FIGURE_MAP.md` for equations, data schemas, and the purpose of each script. The code reproduces the stated fixed experiment. Changing the model or ranges also requires updating the relevant assertions and reference certificates; the current archive is not a general-purpose scalable compiler.

## Source and figure conventions

`paper_sources/` contains the exact main-text and supplement source snapshots used by the table and cross-reference checker. They are included for traceability. Compile the separate full paper package for the PDFs, figures, and REVTeX dependencies; no LaTeX installation is needed to run this repository.

EPS/PDF are vector figures; DPI applies to the JPG exports. EPS cannot represent transparency, so its legend backgrounds are opaque. PDF and JPG legends retain opacity 0.5. Fonts prefer Nimbus Roman/Times New Roman or Nimbus Sans/Arial, with included Matplotlib fonts as fallbacks. Font availability can change appearance, but not the numerical values. PDF/EPS timestamps and font metadata can also change file hashes between runs.

## Citation and deposition

Please cite the accompanying manuscript by Kashif Ammar Yasir. `GITHUB_UPLOAD.md` gives deposition steps and the availability wording to insert after the repository URL exists. The archive does not select a reuse license on the author's behalf; add the license you intend to grant before distributing it as open-source software.
